<div class="page-heading">
    <div class="page-title">
        <div class="row">
            <div class="col-12 col-md-6 order-md-1 order-last">
                <h3>Surat Masuk</h3>
                <p class="text-subtitle text-muted">Data Surat Masuk Dapat Di lihat Pada Tabel Dibawah Ini!</p>
            </div>
            <div class="col-12 col-md-6 order-md-2 order-first">
                <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?= base_url('dashboard')?>">Dashboard</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Surat Masuk</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
    <!-- sweet alert -->
    <?php if($this->session->flashdata('flash') ) : ?>
    <div class="row mt-2">
        <div class="col-md-6">
            <div class="alert alert-success alert-dismissible show fade">
                <strong>Data Surat </strong> <?= $this->session->flashdata('flash'); ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <!-- end sweet alert -->

    <!-- Basic Tables start -->
    <section class="section">
        <div class="card">
            <div class="card-header">
            <?php if($level['level_user'] == 'admin'): ?>
            <a href="<?= base_url()?>sm/tambah" class="btn icon icon-right btn-primary">Tambah <i class="bi bi-plus-circle-fill"></i></a>
            <?php endif;?>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                <table class="table" id="table1">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Tanggal Terima</th>
                            <th>Tanggal Arsipkan</th>
                            <th>Nomor Surat</th>
                            <th>Ke Bagian</th>
                            <th>Perihal</th>
                            <th>Instansi</th>
                            <th>Alamat Pengirim</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $no = 1; foreach($surat_masuk as $sm) :?>
                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $sm['tgl_diterima'] ?></td>
                            <td><?= $sm['tgl_diarsipkan'] ?></td>
                            <td><?= $sm['no_surat'] ?></td>
                            <td><?= $sm['ke_bagian'] ?></td>
                            <td><?= $sm['perihal_suratmasuk'] ?></td>
                            <td><?= $sm['instansi'] ?></td>
                            <td><?= $sm['alamat_pengirim'] ?></td>
                            
                            <td>
                            <?php if($level['level_user'] == 'admin'): ?>
                                <a href="<?= base_url(); ?>sm/detail/<?= $sm['id_suratmasuk'];?>" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Detail"><i class="bi bi-eye-fill"></i></a>
                                <a href="<?= base_url(); ?>sm/ubah/<?= $sm['id_suratmasuk'];?>" class="my-2 btn btn-sm btn-success" data-bs-toggle="tooltip" data-bs-placement="top" title="Edit"><i class="bi bi-pencil-square"></i></a>
                                <a href="<?= base_url(); ?>sm/hapus/<?= $sm['id_suratmasuk'];?>" class="btn btn-sm btn-danger" data-bs-toggle="tooltip" data-bs-placement="top" title="Hapus" onclick="return confirm('Yakin Menghapus Data ?');"><i class="bi bi-trash3-fill"></i></a>
                                <!-- <a href="<?= base_url(); ?>sm/unduh/<?= $sm['file_surat']; ?>" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Unduh"><i class="bi bi-eye-fill"></i></a> -->
                                <form action="<?= base_url()?>sm/unduh" method="post">
                                    <input type="HIDDEN" name="file_surat" value="<?=$sm['file_surat']?>">
                                    <button type="submit" class="my-2 btn btn-sm btn-secondary" data-bs-toggle="tooltip" data-bs-placement="top" title="Unduh">
                                    <i class="bi bi-download"></i>
                                    </button>
                                </form>
                                <?php elseif($level['level_user'] == 'pimpinan'): ?>
                                    <a href="<?= base_url(); ?>sm/detail/<?= $sm['id_suratmasuk'];?>" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Detail"><i class="bi bi-eye-fill"></i></a>
                                    <form action="<?= base_url()?>sm/unduh" method="post">
                                        <input type="HIDDEN" name="file_surat" value="<?=$sm['file_surat']?>">
                                        <button type="submit" class="my-2 btn btn-sm btn-success" data-bs-toggle="tooltip" data-bs-placement="top" title="Unduh">
                                        <i class="bi bi-download"></i>
                                    </button>
                                    </form>
                                    <?php elseif($level['level_user'] == 'kasi'): ?>
                                        <a href="<?= base_url(); ?>sm/detail/<?= $sm['id_suratmasuk'];?>" class="btn btn-sm btn-primary" data-bs-toggle="tooltip" data-bs-placement="top" title="Detail"><i class="bi bi-eye-fill"></i></a>
                                    <form action="<?= base_url()?>sm/unduh" method="post">
                                    <input type="HIDDEN" name="file_surat" value="<?=$sm['file_surat']?>">
                                    <button type="submit" class="my-2 btn btn-sm btn-success" data-bs-toggle="tooltip" data-bs-placement="top" title="Unduh">
                                    <i class="bi bi-download"></i>
                                    </button>
                                </form>
                                <?php endif;?>
                            </td>
                        </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>
                
                </div>
            </div>
        </div>

    </section>
    <!-- Basic Tables end -->
</div>
